const x;
const y = x, z = x;
