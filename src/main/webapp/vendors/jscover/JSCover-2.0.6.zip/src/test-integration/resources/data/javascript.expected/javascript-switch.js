if (! _$jscoverage['javascript-switch.js']) {
  _$jscoverage['javascript-switch.js'] = {};
  _$jscoverage['javascript-switch.js'].lineData = [];
  _$jscoverage['javascript-switch.js'].lineData[1] = 0;
  _$jscoverage['javascript-switch.js'].lineData[3] = 0;
  _$jscoverage['javascript-switch.js'].lineData[4] = 0;
  _$jscoverage['javascript-switch.js'].lineData[6] = 0;
  _$jscoverage['javascript-switch.js'].lineData[7] = 0;
  _$jscoverage['javascript-switch.js'].lineData[8] = 0;
  _$jscoverage['javascript-switch.js'].lineData[10] = 0;
  _$jscoverage['javascript-switch.js'].lineData[11] = 0;
  _$jscoverage['javascript-switch.js'].lineData[14] = 0;
  _$jscoverage['javascript-switch.js'].lineData[16] = 0;
  _$jscoverage['javascript-switch.js'].lineData[17] = 0;
  _$jscoverage['javascript-switch.js'].lineData[18] = 0;
  _$jscoverage['javascript-switch.js'].lineData[20] = 0;
  _$jscoverage['javascript-switch.js'].lineData[23] = 0;
  _$jscoverage['javascript-switch.js'].lineData[24] = 0;
  _$jscoverage['javascript-switch.js'].lineData[26] = 0;
  _$jscoverage['javascript-switch.js'].lineData[27] = 0;
  _$jscoverage['javascript-switch.js'].lineData[29] = 0;
  _$jscoverage['javascript-switch.js'].lineData[30] = 0;
}
if (! _$jscoverage['javascript-switch.js'].functionData) {
  _$jscoverage['javascript-switch.js'].functionData = [];
}
_$jscoverage['javascript-switch.js'].lineData[1]++;
switch (x) {
  case x:
    _$jscoverage['javascript-switch.js'].lineData[3]++;
    x = 0;
    _$jscoverage['javascript-switch.js'].lineData[4]++;
    break;
  case y:
    _$jscoverage['javascript-switch.js'].lineData[6]++;
    x = 0;
    _$jscoverage['javascript-switch.js'].lineData[7]++;
    y = 0;
    _$jscoverage['javascript-switch.js'].lineData[8]++;
    break;
  default:
    _$jscoverage['javascript-switch.js'].lineData[10]++;
    x = 0;
    _$jscoverage['javascript-switch.js'].lineData[11]++;
    break;
}
_$jscoverage['javascript-switch.js'].lineData[14]++;
switch (x) {
  case 1:
    _$jscoverage['javascript-switch.js'].lineData[16]++;
    let y = 1;
    _$jscoverage['javascript-switch.js'].lineData[17]++;
    f(y);
    _$jscoverage['javascript-switch.js'].lineData[18]++;
    break;
  case 2:
    _$jscoverage['javascript-switch.js'].lineData[20]++;
    break;
}
_$jscoverage['javascript-switch.js'].lineData[23]++;
switch (x) {
  case 1:
    _$jscoverage['javascript-switch.js'].lineData[24]++;
  case 2:
    _$jscoverage['javascript-switch.js'].lineData[26]++;
    x = 2;
    _$jscoverage['javascript-switch.js'].lineData[27]++;
    break;
  default:
    _$jscoverage['javascript-switch.js'].lineData[29]++;
    x = 0;
    _$jscoverage['javascript-switch.js'].lineData[30]++;
    break;
}
