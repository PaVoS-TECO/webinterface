/*
This file has LF line endings.
*/
var x = 1;
