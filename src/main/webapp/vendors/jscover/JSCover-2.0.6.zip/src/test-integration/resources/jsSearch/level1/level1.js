var y = 0;
if (y > 0)
    y--;
y++;