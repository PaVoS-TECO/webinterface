if (! _$jscoverage['javascript-unaryop.js']) {
  _$jscoverage['javascript-unaryop.js'] = {};
  _$jscoverage['javascript-unaryop.js'].lineData = [];
  _$jscoverage['javascript-unaryop.js'].lineData[1] = 0;
  _$jscoverage['javascript-unaryop.js'].lineData[2] = 0;
  _$jscoverage['javascript-unaryop.js'].lineData[3] = 0;
  _$jscoverage['javascript-unaryop.js'].lineData[4] = 0;
  _$jscoverage['javascript-unaryop.js'].lineData[5] = 0;
  _$jscoverage['javascript-unaryop.js'].lineData[6] = 0;
  _$jscoverage['javascript-unaryop.js'].lineData[7] = 0;
}
if (! _$jscoverage['javascript-unaryop.js'].functionData) {
  _$jscoverage['javascript-unaryop.js'].functionData = [];
}
_$jscoverage['javascript-unaryop.js'].lineData[1]++;
x = -x;
_$jscoverage['javascript-unaryop.js'].lineData[2]++;
x = +x;
_$jscoverage['javascript-unaryop.js'].lineData[3]++;
x = !x;
_$jscoverage['javascript-unaryop.js'].lineData[4]++;
x = ~x;
_$jscoverage['javascript-unaryop.js'].lineData[5]++;
x = typeof x;
_$jscoverage['javascript-unaryop.js'].lineData[6]++;
x = typeof 123;
_$jscoverage['javascript-unaryop.js'].lineData[7]++;
x = void x;
