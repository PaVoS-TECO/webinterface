if (! _$jscoverage['javascript-assign.js']) {
  _$jscoverage['javascript-assign.js'] = {};
  _$jscoverage['javascript-assign.js'].lineData = [];
  _$jscoverage['javascript-assign.js'].lineData[1] = 0;
  _$jscoverage['javascript-assign.js'].lineData[2] = 0;
  _$jscoverage['javascript-assign.js'].lineData[3] = 0;
  _$jscoverage['javascript-assign.js'].lineData[4] = 0;
  _$jscoverage['javascript-assign.js'].lineData[5] = 0;
  _$jscoverage['javascript-assign.js'].lineData[6] = 0;
  _$jscoverage['javascript-assign.js'].lineData[7] = 0;
  _$jscoverage['javascript-assign.js'].lineData[8] = 0;
  _$jscoverage['javascript-assign.js'].lineData[9] = 0;
  _$jscoverage['javascript-assign.js'].lineData[10] = 0;
  _$jscoverage['javascript-assign.js'].lineData[11] = 0;
  _$jscoverage['javascript-assign.js'].lineData[12] = 0;
  _$jscoverage['javascript-assign.js'].lineData[13] = 0;
  _$jscoverage['javascript-assign.js'].lineData[14] = 0;
}
if (! _$jscoverage['javascript-assign.js'].functionData) {
  _$jscoverage['javascript-assign.js'].functionData = [];
}
_$jscoverage['javascript-assign.js'].lineData[1]++;
var x = 1;
_$jscoverage['javascript-assign.js'].lineData[2]++;
var y = 1;
_$jscoverage['javascript-assign.js'].lineData[3]++;
x = y;
_$jscoverage['javascript-assign.js'].lineData[4]++;
x += y;
_$jscoverage['javascript-assign.js'].lineData[5]++;
x -= y;
_$jscoverage['javascript-assign.js'].lineData[6]++;
x *= y;
_$jscoverage['javascript-assign.js'].lineData[7]++;
x %= y;
_$jscoverage['javascript-assign.js'].lineData[8]++;
x <<= y;
_$jscoverage['javascript-assign.js'].lineData[9]++;
x >>= y;
_$jscoverage['javascript-assign.js'].lineData[10]++;
x >>>= y;
_$jscoverage['javascript-assign.js'].lineData[11]++;
x &= y;
_$jscoverage['javascript-assign.js'].lineData[12]++;
x |= y;
_$jscoverage['javascript-assign.js'].lineData[13]++;
x ^= y;
_$jscoverage['javascript-assign.js'].lineData[14]++;
x /= y;
