if (! _$jscoverage['@PREFIX@1/2/2.js']) {
  _$jscoverage['@PREFIX@1/2/2.js'] = [];
  _$jscoverage['@PREFIX@1/2/2.js'][1] = 0;
}
_$jscoverage['@PREFIX@1/2/2.js'][1]++;
alert("This is 2");
