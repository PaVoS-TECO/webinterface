if (! _$jscoverage['javascript-crlf.js']) {
  _$jscoverage['javascript-crlf.js'] = {};
  _$jscoverage['javascript-crlf.js'].lineData = [];
  _$jscoverage['javascript-crlf.js'].lineData[4] = 0;
}
if (! _$jscoverage['javascript-crlf.js'].functionData) {
  _$jscoverage['javascript-crlf.js'].functionData = [];
}
_$jscoverage['javascript-crlf.js'].lineData[4]++;
var x = 1;
