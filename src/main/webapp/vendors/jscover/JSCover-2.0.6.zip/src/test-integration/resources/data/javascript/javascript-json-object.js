var obj =  {
        a: 'a',
        b: function () {
            return 1;
        }
    };
