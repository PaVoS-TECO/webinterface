var x;
var y = x, z = x;
