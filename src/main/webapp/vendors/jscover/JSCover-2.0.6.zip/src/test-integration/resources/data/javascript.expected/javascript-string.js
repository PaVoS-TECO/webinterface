if (! _$jscoverage['javascript-string.js']) {
  _$jscoverage['javascript-string.js'] = {};
  _$jscoverage['javascript-string.js'].lineData = [];
  _$jscoverage['javascript-string.js'].lineData[1] = 0;
  _$jscoverage['javascript-string.js'].lineData[2] = 0;
  _$jscoverage['javascript-string.js'].lineData[3] = 0;
  _$jscoverage['javascript-string.js'].lineData[4] = 0;
  _$jscoverage['javascript-string.js'].lineData[5] = 0;
  _$jscoverage['javascript-string.js'].lineData[6] = 0;
  _$jscoverage['javascript-string.js'].lineData[7] = 0;
  _$jscoverage['javascript-string.js'].lineData[8] = 0;
  _$jscoverage['javascript-string.js'].lineData[10] = 0;
}
if (! _$jscoverage['javascript-string.js'].functionData) {
  _$jscoverage['javascript-string.js'].functionData = [];
}
_$jscoverage['javascript-string.js'].lineData[1]++;
x = "";
_$jscoverage['javascript-string.js'].lineData[2]++;
x = '';
_$jscoverage['javascript-string.js'].lineData[3]++;
x = "x";
_$jscoverage['javascript-string.js'].lineData[4]++;
x = 'x';
_$jscoverage['javascript-string.js'].lineData[5]++;
x = "\"";
_$jscoverage['javascript-string.js'].lineData[6]++;
x = '\'';
_$jscoverage['javascript-string.js'].lineData[7]++;
x = "\b\t\n\v\f\r\"'\\";
_$jscoverage['javascript-string.js'].lineData[8]++;
x = new RegExp('x\\(\\)\\\\\\/');
_$jscoverage['javascript-string.js'].lineData[10]++;
x = 'foobar';
