if (! _$jscoverage['javascript-lambda.js']) {
  _$jscoverage['javascript-lambda.js'] = {};
  _$jscoverage['javascript-lambda.js'].lineData = [];
  _$jscoverage['javascript-lambda.js'].lineData[3] = 0;
}
if (! _$jscoverage['javascript-lambda.js'].functionData) {
  _$jscoverage['javascript-lambda.js'].functionData = [];
  _$jscoverage['javascript-lambda.js'].functionData[0] = 0;
}
_$jscoverage['javascript-lambda.js'].lineData[3]++;
var square = function(x) x * x;
