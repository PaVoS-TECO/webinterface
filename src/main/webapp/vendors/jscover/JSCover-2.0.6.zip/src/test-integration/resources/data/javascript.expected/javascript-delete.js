if (! _$jscoverage['javascript-delete.js']) {
  _$jscoverage['javascript-delete.js'] = {};
  _$jscoverage['javascript-delete.js'].lineData = [];
  _$jscoverage['javascript-delete.js'].lineData[1] = 0;
}
if (! _$jscoverage['javascript-delete.js'].functionData) {
  _$jscoverage['javascript-delete.js'].functionData = [];
}
_$jscoverage['javascript-delete.js'].lineData[1]++;
delete x;
