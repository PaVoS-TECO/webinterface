dump("hello");

// test formatting &lt; &gt; &amp;
if ('a' < 'b' && 'a' > 'b') {
  dump("?");
}
