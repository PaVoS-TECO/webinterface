var x = 0;

if (x)
  x = 0;

if (x) {
  x = 0;
}

if (x)
  x = 0;
else
  x = 0;

if (x) {
  x = 0;
}
else {
  x = 0;
}

if (x) {
  x = 0;
}
else if (x) {
  x = 0;
}
else {
  x = 0;
}
