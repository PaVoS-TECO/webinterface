if (! _$jscoverage['javascript-iso-8859-1.js']) {
  _$jscoverage['javascript-iso-8859-1.js'] = {};
  _$jscoverage['javascript-iso-8859-1.js'].lineData = [];
  _$jscoverage['javascript-iso-8859-1.js'].lineData[1] = 0;
  _$jscoverage['javascript-iso-8859-1.js'].lineData[2] = 0;
}
if (! _$jscoverage['javascript-iso-8859-1.js'].functionData) {
  _$jscoverage['javascript-iso-8859-1.js'].functionData = [];
}
_$jscoverage['javascript-iso-8859-1.js'].lineData[1]++;
var s = "e\u00e8\u00e9\u00ea";
_$jscoverage['javascript-iso-8859-1.js'].lineData[2]++;
var r = /e\u00e8\u00e9\u00ea/;
