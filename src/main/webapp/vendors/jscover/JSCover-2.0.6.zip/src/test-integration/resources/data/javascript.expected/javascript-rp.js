if (! _$jscoverage['javascript-rp.js']) {
  _$jscoverage['javascript-rp.js'] = {};
  _$jscoverage['javascript-rp.js'].lineData = [];
  _$jscoverage['javascript-rp.js'].lineData[1] = 0;
  _$jscoverage['javascript-rp.js'].lineData[2] = 0;
}
if (! _$jscoverage['javascript-rp.js'].functionData) {
  _$jscoverage['javascript-rp.js'].functionData = [];
}
_$jscoverage['javascript-rp.js'].lineData[1]++;
x = a + (b - c);
_$jscoverage['javascript-rp.js'].lineData[2]++;
x = a - (b + c);
