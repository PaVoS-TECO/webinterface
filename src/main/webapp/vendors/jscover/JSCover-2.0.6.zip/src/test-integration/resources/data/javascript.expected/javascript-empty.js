if (! _$jscoverage['javascript-empty.js']) {
  _$jscoverage['javascript-empty.js'] = {};
  _$jscoverage['javascript-empty.js'].lineData = [];
}
if (! _$jscoverage['javascript-empty.js'].functionData) {
  _$jscoverage['javascript-empty.js'].functionData = [];
}
