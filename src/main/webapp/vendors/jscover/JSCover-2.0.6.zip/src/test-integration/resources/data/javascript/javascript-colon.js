x:
  y = 0;

y: {
  let y = 1;
  print(y);
}
