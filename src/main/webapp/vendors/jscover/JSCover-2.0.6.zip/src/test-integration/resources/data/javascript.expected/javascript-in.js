if (! _$jscoverage['javascript-in.js']) {
  _$jscoverage['javascript-in.js'] = {};
  _$jscoverage['javascript-in.js'].lineData = [];
  _$jscoverage['javascript-in.js'].lineData[1] = 0;
  _$jscoverage['javascript-in.js'].lineData[2] = 0;
  _$jscoverage['javascript-in.js'].lineData[3] = 0;
}
if (! _$jscoverage['javascript-in.js'].functionData) {
  _$jscoverage['javascript-in.js'].functionData = [];
}
_$jscoverage['javascript-in.js'].lineData[1]++;
var x = {};
_$jscoverage['javascript-in.js'].lineData[2]++;
if ('a' in x) {
  _$jscoverage['javascript-in.js'].lineData[3]++;
  x = null;
}
