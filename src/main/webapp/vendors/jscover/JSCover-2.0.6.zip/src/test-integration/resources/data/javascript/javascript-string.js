x = "";
x = '';
x = "x";
x = 'x';
x = "\"";
x = '\'';
x = "\b\t\n\v\f\r\"\'\\";
x = new RegExp('x\\(\\)\\\\\\/');

x = 'foo\
bar';
