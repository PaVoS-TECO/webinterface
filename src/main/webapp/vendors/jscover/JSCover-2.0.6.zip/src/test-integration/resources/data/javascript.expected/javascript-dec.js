if (! _$jscoverage['javascript-dec.js']) {
  _$jscoverage['javascript-dec.js'] = {};
  _$jscoverage['javascript-dec.js'].lineData = [];
  _$jscoverage['javascript-dec.js'].lineData[1] = 0;
  _$jscoverage['javascript-dec.js'].lineData[2] = 0;
}
if (! _$jscoverage['javascript-dec.js'].functionData) {
  _$jscoverage['javascript-dec.js'].functionData = [];
}
_$jscoverage['javascript-dec.js'].lineData[1]++;
x--;
_$jscoverage['javascript-dec.js'].lineData[2]++;
--x;
