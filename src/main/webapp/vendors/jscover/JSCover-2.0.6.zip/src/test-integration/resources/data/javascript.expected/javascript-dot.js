if (! _$jscoverage['javascript-dot.js']) {
  _$jscoverage['javascript-dot.js'] = {};
  _$jscoverage['javascript-dot.js'].lineData = [];
  _$jscoverage['javascript-dot.js'].lineData[1] = 0;
  _$jscoverage['javascript-dot.js'].lineData[2] = 0;
  _$jscoverage['javascript-dot.js'].lineData[3] = 0;
  _$jscoverage['javascript-dot.js'].lineData[4] = 0;
  _$jscoverage['javascript-dot.js'].lineData[5] = 0;
  _$jscoverage['javascript-dot.js'].lineData[7] = 0;
  _$jscoverage['javascript-dot.js'].lineData[8] = 0;
}
if (! _$jscoverage['javascript-dot.js'].functionData) {
  _$jscoverage['javascript-dot.js'].functionData = [];
}
_$jscoverage['javascript-dot.js'].lineData[1]++;
x.y = y.x;
_$jscoverage['javascript-dot.js'].lineData[2]++;
x["y"] = y["x"];
_$jscoverage['javascript-dot.js'].lineData[3]++;
x[y] = y[x];
_$jscoverage['javascript-dot.js'].lineData[4]++;
x['2y'] = y['var'];
_$jscoverage['javascript-dot.js'].lineData[5]++;
x[''] = y[""];
_$jscoverage['javascript-dot.js'].lineData[7]++;
print(123.0.toString());
_$jscoverage['javascript-dot.js'].lineData[8]++;
({}.toString());
