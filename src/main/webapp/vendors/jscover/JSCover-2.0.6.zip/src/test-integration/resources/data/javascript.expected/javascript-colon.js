if (! _$jscoverage['javascript-colon.js']) {
  _$jscoverage['javascript-colon.js'] = {};
  _$jscoverage['javascript-colon.js'].lineData = [];
  _$jscoverage['javascript-colon.js'].lineData[1] = 0;
  _$jscoverage['javascript-colon.js'].lineData[4] = 0;
  _$jscoverage['javascript-colon.js'].lineData[5] = 0;
  _$jscoverage['javascript-colon.js'].lineData[6] = 0;
}
if (! _$jscoverage['javascript-colon.js'].functionData) {
  _$jscoverage['javascript-colon.js'].functionData = [];
}
_$jscoverage['javascript-colon.js'].lineData[1]++;
x:
  y = 0;
_$jscoverage['javascript-colon.js'].lineData[4]++;
y:
  {
    _$jscoverage['javascript-colon.js'].lineData[5]++;
    let y = 1;
    _$jscoverage['javascript-colon.js'].lineData[6]++;
    print(y);
  }
