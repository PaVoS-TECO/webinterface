if (! _$jscoverage['javascript-for.js']) {
  _$jscoverage['javascript-for.js'] = {};
  _$jscoverage['javascript-for.js'].lineData = [];
  _$jscoverage['javascript-for.js'].lineData[1] = 0;
  _$jscoverage['javascript-for.js'].lineData[2] = 0;
  _$jscoverage['javascript-for.js'].lineData[5] = 0;
  _$jscoverage['javascript-for.js'].lineData[6] = 0;
  _$jscoverage['javascript-for.js'].lineData[9] = 0;
  _$jscoverage['javascript-for.js'].lineData[10] = 0;
  _$jscoverage['javascript-for.js'].lineData[13] = 0;
  _$jscoverage['javascript-for.js'].lineData[14] = 0;
  _$jscoverage['javascript-for.js'].lineData[17] = 0;
  _$jscoverage['javascript-for.js'].lineData[18] = 0;
  _$jscoverage['javascript-for.js'].lineData[20] = 0;
  _$jscoverage['javascript-for.js'].lineData[21] = 0;
}
if (! _$jscoverage['javascript-for.js'].functionData) {
  _$jscoverage['javascript-for.js'].functionData = [];
}
_$jscoverage['javascript-for.js'].lineData[1]++;
for (i in x) {
  _$jscoverage['javascript-for.js'].lineData[2]++;
  x();
}
_$jscoverage['javascript-for.js'].lineData[5]++;
for (var i in x) {
  _$jscoverage['javascript-for.js'].lineData[6]++;
  x();
}
_$jscoverage['javascript-for.js'].lineData[9]++;
for (i = 0; i < x; i++) {
  _$jscoverage['javascript-for.js'].lineData[10]++;
  x();
}
_$jscoverage['javascript-for.js'].lineData[13]++;
for (var j = 0; j < x; j++) {
  _$jscoverage['javascript-for.js'].lineData[14]++;
  x();
}
_$jscoverage['javascript-for.js'].lineData[17]++;
for (i in x) {
  _$jscoverage['javascript-for.js'].lineData[18]++;
  x();
}
_$jscoverage['javascript-for.js'].lineData[20]++;
for (i.value in x) {
  _$jscoverage['javascript-for.js'].lineData[21]++;
  x();
}
