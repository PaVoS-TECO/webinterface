if (! _$jscoverage['javascript-special-characters.js']) {
  _$jscoverage['javascript-special-characters.js'] = {};
  _$jscoverage['javascript-special-characters.js'].lineData = [];
  _$jscoverage['javascript-special-characters.js'].lineData[1] = 0;
  _$jscoverage['javascript-special-characters.js'].lineData[2] = 0;
  _$jscoverage['javascript-special-characters.js'].lineData[5] = 0;
  _$jscoverage['javascript-special-characters.js'].lineData[6] = 0;
  _$jscoverage['javascript-special-characters.js'].lineData[9] = 0;
  _$jscoverage['javascript-special-characters.js'].lineData[10] = 0;
}
if (! _$jscoverage['javascript-special-characters.js'].functionData) {
  _$jscoverage['javascript-special-characters.js'].functionData = [];
  _$jscoverage['javascript-special-characters.js'].functionData[0] = 0;
  _$jscoverage['javascript-special-characters.js'].functionData[1] = 0;
  _$jscoverage['javascript-special-characters.js'].functionData[2] = 0;
}
_$jscoverage['javascript-special-characters.js'].lineData[1]++;
function f() {
  _$jscoverage['javascript-special-characters.js'].functionData[0]++;
  _$jscoverage['javascript-special-characters.js'].lineData[2]++;
  return '\'';
}
_$jscoverage['javascript-special-characters.js'].lineData[5]++;
function g() {
  _$jscoverage['javascript-special-characters.js'].functionData[1]++;
  _$jscoverage['javascript-special-characters.js'].lineData[6]++;
  return "\"";
}
_$jscoverage['javascript-special-characters.js'].lineData[9]++;
function h() {
  _$jscoverage['javascript-special-characters.js'].functionData[2]++;
  _$jscoverage['javascript-special-characters.js'].lineData[10]++;
  return '\\';
}
