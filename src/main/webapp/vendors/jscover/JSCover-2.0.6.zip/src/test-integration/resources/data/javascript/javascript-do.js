var x;

do {
  x = false;
}
while (x);

do
  x = false;
while (x);
