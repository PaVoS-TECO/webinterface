if (! _$jscoverage['javascript-new.js']) {
  _$jscoverage['javascript-new.js'] = {};
  _$jscoverage['javascript-new.js'].lineData = [];
  _$jscoverage['javascript-new.js'].lineData[1] = 0;
  _$jscoverage['javascript-new.js'].lineData[2] = 0;
  _$jscoverage['javascript-new.js'].lineData[3] = 0;
  _$jscoverage['javascript-new.js'].lineData[4] = 0;
  _$jscoverage['javascript-new.js'].lineData[5] = 0;
  _$jscoverage['javascript-new.js'].lineData[6] = 0;
  _$jscoverage['javascript-new.js'].lineData[7] = 0;
  _$jscoverage['javascript-new.js'].lineData[8] = 0;
  _$jscoverage['javascript-new.js'].lineData[9] = 0;
  _$jscoverage['javascript-new.js'].lineData[10] = 0;
  _$jscoverage['javascript-new.js'].lineData[11] = 0;
  _$jscoverage['javascript-new.js'].lineData[12] = 0;
  _$jscoverage['javascript-new.js'].lineData[13] = 0;
}
if (! _$jscoverage['javascript-new.js'].functionData) {
  _$jscoverage['javascript-new.js'].functionData = [];
  _$jscoverage['javascript-new.js'].functionData[0] = 0;
}
_$jscoverage['javascript-new.js'].lineData[1]++;
function X() {
  _$jscoverage['javascript-new.js'].functionData[0]++;
}
_$jscoverage['javascript-new.js'].lineData[2]++;
x = new X();
_$jscoverage['javascript-new.js'].lineData[3]++;
x = new X(1);
_$jscoverage['javascript-new.js'].lineData[4]++;
x = new X(1, 2);
_$jscoverage['javascript-new.js'].lineData[5]++;
x = new X();
_$jscoverage['javascript-new.js'].lineData[6]++;
x = new (X)();
_$jscoverage['javascript-new.js'].lineData[7]++;
x = new (X)(1);
_$jscoverage['javascript-new.js'].lineData[8]++;
x = new (X)(1, 2);
_$jscoverage['javascript-new.js'].lineData[9]++;
x = new (X)();
_$jscoverage['javascript-new.js'].lineData[10]++;
x = new (f())();
_$jscoverage['javascript-new.js'].lineData[11]++;
x = new (f())(1);
_$jscoverage['javascript-new.js'].lineData[12]++;
x = new (f())(1, 2);
_$jscoverage['javascript-new.js'].lineData[13]++;
x = new (f())();
