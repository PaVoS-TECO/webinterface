if (! _$jscoverage['javascript-cr.js']) {
  _$jscoverage['javascript-cr.js'] = {};
  _$jscoverage['javascript-cr.js'].lineData = [];
  _$jscoverage['javascript-cr.js'].lineData[4] = 0;
}
if (! _$jscoverage['javascript-cr.js'].functionData) {
  _$jscoverage['javascript-cr.js'].functionData = [];
}
_$jscoverage['javascript-cr.js'].lineData[4]++;
var x = 1;
