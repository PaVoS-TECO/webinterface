// https://developer.mozilla.org/en/New_in_JavaScript_1.8

var square = function(x) x * x;
