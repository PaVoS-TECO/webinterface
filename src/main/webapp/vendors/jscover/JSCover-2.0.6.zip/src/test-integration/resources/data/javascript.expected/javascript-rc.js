if (! _$jscoverage['javascript-rc.js']) {
  _$jscoverage['javascript-rc.js'] = {};
  _$jscoverage['javascript-rc.js'].lineData = [];
  _$jscoverage['javascript-rc.js'].lineData[1] = 0;
  _$jscoverage['javascript-rc.js'].lineData[4] = 0;
}
if (! _$jscoverage['javascript-rc.js'].functionData) {
  _$jscoverage['javascript-rc.js'].functionData = [];
}
_$jscoverage['javascript-rc.js'].lineData[1]++;
x = {
  x: y};
_$jscoverage['javascript-rc.js'].lineData[4]++;
x = {
  x: y, 
  y: x};
