var obj = {
  x setter: 3
};
