package jscover.util;

import java.util.Date;

public class DateTimeImpl implements DateTime {
    public Date getDate() {
        return new Date();
    }
}
