package jscover.util;

import java.util.Date;

public interface DateTime {
    Date getDate();
}
