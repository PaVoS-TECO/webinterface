cd ../..
java -jar target/dist/JSCover-all.jar -ws --document-root=doc/example --report-dir=target/local-storage-server --local-storage