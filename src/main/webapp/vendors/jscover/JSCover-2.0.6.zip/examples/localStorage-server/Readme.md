Demonstrates:
 - running tests with intermediate page results stored in HTML5 local-storage (i.e. no iframes or child windows)
 - instrumenting the JavaScript as a web-server and save the report

To run this example:
 - Download and install Selenium IDE from http://docs.seleniumhq.org/download/
 - Start the JSCover server jscover-server.bat/jscover-server.sh
 - Load selenium-ide.html in the Selenium IDE and run
 - Results should be stored in <JSCover-root>/target/local-storage-server