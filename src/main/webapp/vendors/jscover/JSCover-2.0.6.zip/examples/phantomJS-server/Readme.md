This example runs some QUnit tests and stores the coverage results in `<JSCover-root>/target/phantom-server/phantom`

See the documentation at http://tntim96.github.io/JSCover/manual/manual.xml#automatingPhantomJS