See the documentation at http://tntim96.github.io/JSCover/manual/manual.xml#gettingStartedProxy

Coverage results are stored at `<JSCover-root>/target/jscover-proxy`