cd ../..
java -cp target/dist/JSCover-all.jar jscover.server.SimpleWebServer . 8080