Simple file-system example

See the documentation at http://tntim96.github.io/JSCover/manual/manual.xml#gettingStartedFileSystem

This example instruments the JavaScript example in `<JSCover-root>/doc/example` to `<JSCover-root>/target/example-fs`
