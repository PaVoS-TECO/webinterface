cd ../..
java -jar target/dist/JSCover-all.jar -ws --proxy --port=3128 --report-dir=target/local-storage-proxy --local-storage