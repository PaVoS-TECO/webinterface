cd ../..
java -jar target/dist/JSCover-all.jar -fs --local-storage doc/example target/example-fs-localStorage
